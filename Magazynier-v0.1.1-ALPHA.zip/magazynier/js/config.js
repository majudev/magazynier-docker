var baseUrl = "http://localhost/magazynier";
var apiUrl = "http://localhost/api";
var appName = "Magazynier";

var slashBaseUrl = baseUrl;
if(slashBaseUrl == "") slashBaseUrl = "/";